package Project;

import java.util.*;
public class RockPaperScissor 
{
   static
   {
	   System.out.println("****************************************");
	   System.out.println("***Welcome to Rock Paper Scissor Game***");
	   System.out.println("****************************************");
   }
   public static void main(String[] args) 
   {
	  try
	  {
	     Scanner sc = new Scanner(System.in);
	     System.out.println("Press 0 for Rock , Press 1 for Paper , Press 2 for Scissor");
	     int userInput = sc.nextInt();
	     System.out.println("Your choice : "+userInput);
	     
	    if(userInput<0 || userInput>=3)
	     {
		   System.out.println("Invalid Input");
		   System.exit(0);
	     }
	  
	     Random ref = new Random();
	     int computerInput = ref.nextInt(3);
	  
	     if(computerInput==0)
	     {
		   System.out.println("Computer choice : "+computerInput);
	     }
	    else if(computerInput==1)
	     {
		   System.out.println("Computer choice : "+computerInput);
	     }
	    else if(computerInput==2)
	     {
		   System.out.println("Computer choice : "+computerInput);
	     }
	    if(userInput==computerInput)
	     {
		   System.out.println("Draw");
	     }
	    else if((userInput==0 && computerInput==2) || (userInput==1 && computerInput==0) || (userInput==2 && computerInput==1))
	    {
		  System.out.println("You Win");
	    }
	    else
	    {
		  System.out.println("Computer Win");
	    }
	  }
	  catch(Exception e)
	  {
		  System.out.println("Input Mismatch");
	  }
   }
}
